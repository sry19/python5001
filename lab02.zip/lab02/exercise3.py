def main():
    #print the sum of two integers
    x=int(float(input("Enter a first value: ")))
    y=int(float(input("Enter a second value: ")))
    print("The sum of",x,"+",y,"is",x+y)

main()